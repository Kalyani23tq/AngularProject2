import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-templet-forms-demo',
  templateUrl: './templet-forms-demo.component.html',
  styleUrls: ['./templet-forms-demo.component.css']
})
export class TempletFormsDemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
