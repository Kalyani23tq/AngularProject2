export interface IEmp {
    code:String;
    name:String;
    sal:Number;
}
